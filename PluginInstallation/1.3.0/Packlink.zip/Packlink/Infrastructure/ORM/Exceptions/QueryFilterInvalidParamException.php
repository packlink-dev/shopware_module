<?php

namespace Packlink\Infrastructure\ORM\Exceptions;

use Packlink\Infrastructure\Exceptions\BaseException;

/**
 * Class QueryFilterInvalidParamException.
 *
 * @package Packlink\Infrastructure\ORM\Exceptions
 */
class QueryFilterInvalidParamException extends BaseException
{
}
