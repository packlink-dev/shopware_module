<?php

namespace Packlink\Infrastructure\TaskExecution\Exceptions;

use Packlink\Infrastructure\Exceptions\BaseException;

/**
 * Class TaskRunnerStatusStorageUnavailableException.
 *
 * @package Packlink\Infrastructure\TaskExecution\Exceptions
 */
class TaskRunnerStatusStorageUnavailableException extends BaseException
{
}
