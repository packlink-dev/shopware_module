<?php

namespace Packlink\Exceptions;

use Exception;

class FailedToRetrieveCheckoutAddressException extends Exception
{
}