<?php

namespace Packlink\Infrastructure\TaskExecution\Exceptions;

use Packlink\Infrastructure\Exceptions\BaseException;

/**
 * Class QueueItemDeserializationException.
 *
 * @package Packlink\Infrastructure\TaskExecution\Exceptions
 */
class QueueItemDeserializationException extends BaseException
{
}
