<?php

namespace Packlink\Infrastructure\TaskExecution\Exceptions;

use Packlink\Infrastructure\Exceptions\BaseException;

/**
 * Class TaskRunnerStatusChangeException.
 *
 * @package Packlink\Infrastructure\TaskExecution\Exceptions
 */
class TaskRunnerStatusChangeException extends BaseException
{
}
