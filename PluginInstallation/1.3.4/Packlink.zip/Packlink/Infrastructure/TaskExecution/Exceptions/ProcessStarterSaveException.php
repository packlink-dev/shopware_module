<?php

namespace Packlink\Infrastructure\TaskExecution\Exceptions;

use Packlink\Infrastructure\Exceptions\BaseException;

/**
 * Class ProcessStarterSaveException
 *
 * @package Packlink\Infrastructure\TaskExecution\Exceptions
 */
class ProcessStarterSaveException extends BaseException
{
}
