<?php

namespace Packlink\Infrastructure\Exceptions;

/**
 * Class BaseException. All exceptions defined in this package should inherit from this class.
 *
 * @package Packlink\Infrastructure\Exceptions
 */
class BaseException extends \Exception
{
}
