<?php

namespace Packlink\Infrastructure\ORM\Exceptions;

use Packlink\Infrastructure\Exceptions\BaseException;

/**
 * Class EntityClassException.
 *
 * @package Packlink\Infrastructure\ORM\Exceptions
 */
class EntityClassException extends BaseException
{
}
