<?php

namespace Packlink\BusinessLogic\DTO\Exceptions;

use Packlink\Infrastructure\Exceptions\BaseException;

/**
 * Class FrontDtoNotRegisteredException.
 *
 * @package Packlink\BusinessLogic\DTO\Exceptions
 */
class FrontDtoNotRegisteredException extends BaseException
{
}
