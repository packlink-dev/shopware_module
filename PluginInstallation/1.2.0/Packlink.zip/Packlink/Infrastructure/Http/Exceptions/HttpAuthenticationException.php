<?php

namespace Packlink\Infrastructure\Http\Exceptions;

/**
 * Class HttpAuthenticationException.
 *
 * @package Packlink\Infrastructure\Utility\Exceptions
 */
class HttpAuthenticationException extends HttpBaseException
{

}
