<?php

namespace Packlink\Infrastructure\TaskExecution\Exceptions;

use Packlink\Infrastructure\Exceptions\BaseException;

/**
 * Class AbortTaskExecutionException.
 *
 * @package Packlink\Infrastructure\TaskExecution\Exceptions
 */
class AbortTaskExecutionException extends BaseException
{
}
