<?php

namespace Packlink\Infrastructure\TaskExecution\Exceptions;

use Packlink\Infrastructure\Exceptions\BaseException;

/**
 * Class TaskRunnerRunException.
 *
 * @package Packlink\Infrastructure\TaskExecution\Exceptions
 */
class TaskRunnerRunException extends BaseException
{
}
