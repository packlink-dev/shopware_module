<?php

namespace Packlink\BusinessLogic\ShipmentDraft\Exceptions;

use Packlink\Infrastructure\Exceptions\BaseException;

/**
 * Class DraftTaskMapNotFound.
 *
 * @package Packlink\BusinessLogic\ShipmentDraft\Exceptions
 */
class DraftTaskMapNotFound extends BaseException
{
}
