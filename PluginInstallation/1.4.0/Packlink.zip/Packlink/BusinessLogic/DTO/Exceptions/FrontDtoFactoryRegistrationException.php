<?php

namespace Packlink\BusinessLogic\DTO\Exceptions;

use Packlink\Infrastructure\Exceptions\BaseException;

/**
 * Class FrontDtoFactoryRegistrationException.
 *
 * @package Packlink\BusinessLogic\DTO\Exceptions
 */
class FrontDtoFactoryRegistrationException extends BaseException
{
}
