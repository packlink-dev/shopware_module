<?php

namespace Packlink\Infrastructure\ORM\Exceptions;

use Packlink\Infrastructure\Exceptions\BaseException;

/**
 * Class RepositoryNotRegisteredException.
 *
 * @package Packlink\Infrastructure\ORM\Exceptions
 */
class RepositoryNotRegisteredException extends BaseException
{
}
