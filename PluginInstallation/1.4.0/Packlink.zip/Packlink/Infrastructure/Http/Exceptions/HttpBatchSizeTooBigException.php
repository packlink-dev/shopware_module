<?php

namespace Packlink\Infrastructure\Http\Exceptions;

/**
 * Class HttpBatchSizeTooBigException.
 *
 * @package Packlink\Infrastructure\Utility\Exceptions
 */
class HttpBatchSizeTooBigException extends HttpBaseException
{
}
