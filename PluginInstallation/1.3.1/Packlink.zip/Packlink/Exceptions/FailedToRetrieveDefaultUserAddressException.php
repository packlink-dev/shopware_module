<?php

namespace Packlink\Exceptions;

use Exception;

class FailedToRetrieveDefaultUserAddressException extends Exception
{
}