<?php

namespace Packlink\Infrastructure\TaskExecution\TaskEvents;

use Packlink\Infrastructure\Utility\Events\Event;

/**
 * Class TickEvent.
 *
 * @package Packlink\Infrastructure\Scheduler
 */
class TickEvent extends Event
{
    /**
     * Fully qualified name of this class.
     */
    const CLASS_NAME = __CLASS__;
}
