<?php

namespace Packlink\Infrastructure\Logger\Interfaces;

use Packlink\Infrastructure\Logger\LogData;

/**
 * Interface LoggerAdapter.
 *
 * @package Packlink\Infrastructure\Logger\Interfaces
 */
interface LoggerAdapter
{
    /**
     * Log message in system
     *
     * @param LogData $data
     */
    public function logMessage(LogData $data);
}
