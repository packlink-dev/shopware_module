<?php

namespace Packlink\BusinessLogic\ShippingMethod\Exceptions;

use Packlink\Infrastructure\Exceptions\BaseException;

/**
 * Class FixedPriceValueOutOfBoundsException
 *
 * @package Packlink\BusinessLogic\ShippingMethod\Exceptions
 */
class FixedPriceValueOutOfBoundsException extends BaseException
{
}