<?php

namespace Packlink\Infrastructure\Http\Exceptions;

/**
 * Class HttpCommunicationException.
 *
 * @package Packlink\Infrastructure\Utility\Exceptions
 */
class HttpCommunicationException extends HttpBaseException
{

}
