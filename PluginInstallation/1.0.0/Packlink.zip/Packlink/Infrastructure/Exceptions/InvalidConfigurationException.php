<?php

namespace Packlink\Infrastructure\Exceptions;

/**
 * Class InvalidConfigurationException.
 *
 * @package Packlink\Infrastructure\Exceptions
 */
class InvalidConfigurationException extends BaseException
{

}
