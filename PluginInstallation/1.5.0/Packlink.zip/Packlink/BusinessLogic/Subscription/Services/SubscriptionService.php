<?php

namespace Packlink\BusinessLogic\Subscription\Services;

use Packlink\Infrastructure\Http\Exceptions\HttpAuthenticationException;
use Packlink\Infrastructure\Http\Exceptions\HttpCommunicationException;
use Packlink\Infrastructure\Http\Exceptions\HttpRequestException;
use Packlink\Infrastructure\ServiceRegister;
use Packlink\BusinessLogic\BaseService;
use Packlink\BusinessLogic\Subscription\Http\SubscriptionProxy;
use Packlink\BusinessLogic\Subscription\Interfaces\SubscriptionServiceInterface;

class SubscriptionService extends BaseService implements SubscriptionServiceInterface
{
    /**
     * Singleton instance of this class.
     *
     * @var static
     */
    protected static $instance;


    /**
     * @return bool
     *
     * @throws HttpAuthenticationException
     * @throws HttpCommunicationException
     * @throws HttpRequestException
     */
    public function hasPlusSubscription()
    {
        $response = $this->getSubscriptionProxy()->getSubscriptionFeatureBehaviours();

        if ($response->subscription === null ||
            !isset($response->subscription['plan_name'], $response->subscription['state'])) {

            return false;
        }

        return strtolower($response->subscription['plan_name']) === 'plus' &&
            strtolower($response->subscription['state']) === 'active';
    }

    /**
     * Returns proxy instance.
     *
     * @return object instance.
     */
    protected function getSubscriptionProxy()
    {
        return ServiceRegister::getService(SubscriptionProxy::CLASS_NAME);
    }

}