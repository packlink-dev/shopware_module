<?php

namespace Packlink\Infrastructure\ORM\Exceptions;

use Packlink\Infrastructure\Exceptions\BaseException;

/**
 * Class RepositoryClassException.
 *
 * @package Packlink\Infrastructure\ORM\Exceptions
 */
class RepositoryClassException extends BaseException
{
}
