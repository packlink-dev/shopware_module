<?php

namespace Packlink\Infrastructure\Http\Exceptions;

/**
 * Class HttpUnhandledException.
 *
 * @package Packlink\Infrastructure\Utility\Exceptions
 */
class HttpUnhandledException extends HttpBaseException
{

}
