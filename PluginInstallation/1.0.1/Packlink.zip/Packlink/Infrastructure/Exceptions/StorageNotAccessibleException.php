<?php

namespace Packlink\Infrastructure\Exceptions;

/**
 * Class StorageNotAccessibleException.
 *
 * @package Packlink\Infrastructure\Exceptions
 */
class StorageNotAccessibleException extends BaseException
{
}
