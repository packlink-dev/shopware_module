<?php

use Logeecom\Infrastructure\ORM\QueryFilter\QueryFilter;
use Logeecom\Infrastructure\ORM\RepositoryRegistry;
use Shopware\Components\CSRFWhitelistAware;

class Shopware_Controllers_Frontend_PacklinkTest extends Enlight_Controller_Action implements CSRFWhitelistAware
{
    /**
     * Returns a list with actions which should not be validated for CSRF protection
     *
     * @return string[]
     */
    public function getWhitelistedCSRFActions()
    {
        return ['test'];
    }

    public function testAction()
    {
        $repository = RepositoryRegistry::getQueueItemRepository();
        $filter = new QueryFilter();
        $filter->where('id', '=', 140);

        $task = $repository->selectOne($filter);
        $task->getTask()->execute();
    }
}