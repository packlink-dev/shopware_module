// Packlink order list controller
// {namespace name=backend/packlink/configuration}

Ext.define('Shopware.apps.Packlink.controller.OrderListController', {
    /**
     * Override the order list main controller
     * @string
     */
    override: 'Shopware.apps.Order.controller.List',

    init: function () {
        let me = this;

        // me.callParent will execute the init function of the overridden controller
        me.callParent(arguments);

        me.control(
            {
                'order-list': {
                    cellclick: function (grid, cell, index, record, row, rowIndex, event) {
                        if (event.target && event.target.hasAttribute('data-pl-label')) {
                            event.target.classList.remove('sprite-tag');
                            event.target.classList.add('sprite-tag-label-black');
                        }
                    },
                    plPrintLabels: function (grid) {
                       if (grid.plOrderCheckboxes) {
                           let selected = grid.plOrderCheckboxes.getSelection();
                           if (selected && selected.length !== 0) {
                               grid.getStore().reload();
                           }
                       }
                    }
                }
            }
        )
    }
});