//{block name="backend/order/model/order/fields"}
// {$smarty.block.parent}

{ name : 'plReferenceUrl', type: 'string' },

//{/block}