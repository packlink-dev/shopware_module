//{block name="backend/order/model/order/fields"}
// {$smarty.block.parent}

{
    name: 'plReferenceUrl', type
:
    'string'
}
,
{
    name: 'plHasLabel', type
:
    'boolean', defaultValue
:
    false
}
,
{
    name: 'plIsLabelPrinted', type
:
    'boolean', defaultValue
:
    false
}
,
{
    name: 'plIsDeleted', type
:
    'boolean', defaultValue
:
    false
}
,
{
    name: 'plDraftStatus', type
:
    'string'
}
,
{
    name: 'plMessage', type
:
    'string'
}
,
{
    name: 'plReference', type
:
    'string'
}
,

//{/block}