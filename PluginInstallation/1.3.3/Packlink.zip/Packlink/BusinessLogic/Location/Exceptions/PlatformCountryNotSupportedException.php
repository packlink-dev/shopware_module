<?php

namespace Packlink\BusinessLogic\Location\Exceptions;

use Packlink\Infrastructure\Exceptions\BaseException;

/**
 * Class PlatformCountryNotSupportedException.
 *
 * @package Packlink\BusinessLogic\Location\Exceptions
 */
class PlatformCountryNotSupportedException extends BaseException
{
}