<?php

namespace Packlink\Infrastructure\Http\Exceptions;

/**
 * Class HttpRequestException.
 *
 * @package Packlink\Infrastructure\Utility\Exceptions
 */
class HttpRequestException extends HttpBaseException
{

}
