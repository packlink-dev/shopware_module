<?php

namespace Packlink\Infrastructure\TaskExecution\Exceptions;

use Packlink\Infrastructure\Exceptions\BaseException;

/**
 * Class QueueItemSaveException.
 *
 * @package Packlink\Infrastructure\TaskExecution\Exceptions
 */
class QueueItemSaveException extends BaseException
{
}
