<?php

namespace Packlink\Infrastructure\Http\Exceptions;

use Packlink\Infrastructure\Exceptions\BaseException;

/**
 * Class HttpBaseException. All Http exceptions should inherit from this class.
 *
 * @package Packlink\Infrastructure\Utility\Exceptions
 */
class HttpBaseException extends BaseException
{
}
