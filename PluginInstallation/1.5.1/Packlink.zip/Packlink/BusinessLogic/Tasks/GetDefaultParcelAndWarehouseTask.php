<?php

namespace Packlink\BusinessLogic\Tasks;

use Packlink\Infrastructure\ServiceRegister;
use Packlink\Infrastructure\TaskExecution\Task;
use Packlink\BusinessLogic\User\UserAccountService;

/**
 * Class GetDefaultParcelAndWarehouseTask
 * @package Packlink\BusinessLogic\Tasks
 */
class GetDefaultParcelAndWarehouseTask extends Task
{
    /**
     * Transforms array into an serializable object,
     *
     * @param array $array Data that is used to instantiate serializable object.
     *
     * @return \Packlink\Infrastructure\Serializer\Interfaces\Serializable
     *      Instance of serialized object.
     */
    public static function fromArray(array $array)
    {
        return new static();
    }

    /**
     * Transforms serializable object into an array.
     *
     * @return array Array representation of a serializable object.
     */
    public function toArray()
    {
        return array();
    }

    /**
     * @inheritDoc
     */
    public function __serialize()
    {
        return $this->toArray();
    }

    /**
     * @inheritDoc
     */
    public function __unserialize($data)
    {
    }

    /**
     * Runs task logic.
     *
     * @throws \Packlink\Infrastructure\Http\Exceptions\HttpAuthenticationException
     * @throws \Packlink\Infrastructure\Http\Exceptions\HttpBaseException
     * @throws \Packlink\Infrastructure\Http\Exceptions\HttpCommunicationException
     * @throws \Packlink\Infrastructure\Http\Exceptions\HttpRequestException
     */
    public function execute()
    {
        /** @var UserAccountService $userAccountService */
        $userAccountService = ServiceRegister::getService(UserAccountService::CLASS_NAME);

        $userAccountService->setDefaultParcel(true);
        $this->reportProgress(50);

        $userAccountService->setWarehouseInfo(true);
        $this->reportProgress(100);
    }
}
