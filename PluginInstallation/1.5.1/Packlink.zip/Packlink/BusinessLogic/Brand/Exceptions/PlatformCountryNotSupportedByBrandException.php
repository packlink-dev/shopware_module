<?php


namespace Packlink\BusinessLogic\Brand\Exceptions;

use Packlink\Infrastructure\Exceptions\BaseException;

/**
 * Class PlatformCountryNotSupportedByBrandException
 *
 * @package Packlink\BusinessLogic\Brand\Exceptions
 */
class PlatformCountryNotSupportedByBrandException extends BaseException
{

}