<?php

namespace Packlink\BusinessLogic\Order\Exceptions;

use Packlink\Infrastructure\Exceptions\BaseException;

/**
 * Class EmptyOrderException
 *
 * @package Packlink\BusinessLogic\Order\Exceptions
 */
class EmptyOrderException extends BaseException
{
}