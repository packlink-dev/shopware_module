<?php

namespace Packlink\BusinessLogic\Order\Exceptions;

use Packlink\Infrastructure\Exceptions\BaseException;

/**
 * Class OrderNotFound.
 *
 * @package Packlink\BusinessLogic\Order\Exceptions
 */
class OrderNotFound extends BaseException
{
}
