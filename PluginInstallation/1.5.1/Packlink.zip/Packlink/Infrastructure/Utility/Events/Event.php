<?php

namespace Packlink\Infrastructure\Utility\Events;

/**
 * Class Event.
 *
 * @package Packlink\Infrastructure\Utility\Events
 */
abstract class Event
{
    /**
     * Fully qualified name of this class.
     */
    const CLASS_NAME = __CLASS__;
}
