<?php

namespace Packlink\Infrastructure;

use Packlink\Infrastructure\TaskExecution\AsyncProcessStarterService;
use Packlink\Infrastructure\TaskExecution\Interfaces\AsyncProcessService;
use Packlink\Infrastructure\TaskExecution\Interfaces\TaskRunnerStatusStorage;
use Packlink\Infrastructure\TaskExecution\Interfaces\TaskRunnerWakeup;
use Packlink\Infrastructure\TaskExecution\QueueService;
use Packlink\Infrastructure\TaskExecution\RunnerStatusStorage;
use Packlink\Infrastructure\TaskExecution\TaskRunner;
use Packlink\Infrastructure\TaskExecution\TaskRunnerWakeupService;
use Packlink\Infrastructure\Utility\Events\EventBus;
use Packlink\Infrastructure\Utility\GuidProvider;
use Packlink\Infrastructure\Utility\TimeProvider;

/**
 * Class BootstrapComponent.
 *
 * @package Packlink\Infrastructure
 */
class BootstrapComponent
{
    /**
     * Initializes infrastructure components.
     */
    public static function init()
    {
        static::initServices();
        static::initRepositories();
        static::initEvents();
    }

    /**
     * Initializes services and utilities.
     */
    protected static function initServices()
    {
        ServiceRegister::registerService(
            TimeProvider::CLASS_NAME,
            function () {
                return TimeProvider::getInstance();
            }
        );
        ServiceRegister::registerService(
            GuidProvider::CLASS_NAME,
            function () {
                return GuidProvider::getInstance();
            }
        );
        ServiceRegister::registerService(
            EventBus::CLASS_NAME,
            function () {
                return EventBus::getInstance();
            }
        );
        ServiceRegister::registerService(
            AsyncProcessService::CLASS_NAME,
            function () {
                return AsyncProcessStarterService::getInstance();
            }
        );
        ServiceRegister::registerService(
            QueueService::CLASS_NAME,
            function () {
                return new QueueService();
            }
        );
        ServiceRegister::registerService(
            TaskRunnerWakeup::CLASS_NAME,
            function () {
                return new TaskRunnerWakeupService();
            }
        );
        ServiceRegister::registerService(
            TaskRunner::CLASS_NAME,
            function () {
                return new TaskRunner();
            }
        );
        ServiceRegister::registerService(
            TaskRunnerStatusStorage::CLASS_NAME,
            function () {
                return new RunnerStatusStorage();
            }
        );
    }

    /**
     * Initializes repositories.
     */
    protected static function initRepositories()
    {
    }

    /**
     * Initializes events.
     */
    protected static function initEvents()
    {
    }
}
