<?php

namespace Packlink\Infrastructure\Logger\Interfaces;

/**
 * Interface ShopLoggerAdapter.
 *
 * @package Packlink\Infrastructure\Logger\Interfaces
 */
interface ShopLoggerAdapter extends LoggerAdapter
{
    /**
     * Fully qualified name of this interface.
     */
    const CLASS_NAME = __CLASS__;
}
