<?php

namespace Packlink\Infrastructure\TaskExecution\Exceptions;

use Packlink\Infrastructure\Exceptions\BaseException;

/**
 * Class ProcessStorageGetException.
 *
 * @package Packlink\Infrastructure\TaskExecution\Exceptions
 */
class ProcessStorageGetException extends BaseException
{
}
