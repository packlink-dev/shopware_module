<?php

namespace Packlink\Infrastructure\TaskExecution\Exceptions;

use Packlink\Infrastructure\Exceptions\BaseException;

/**
 * Class SyncTaskFailedException.
 *
 * @package Packlink\Infrastructure\TaskExecution\Exceptions
 */
class SyncTaskFailedException extends BaseException
{
}
