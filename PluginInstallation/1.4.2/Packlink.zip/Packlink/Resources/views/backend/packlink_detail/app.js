//{block name="backend/order/application"}
// {include file="backend/packlink_detail/utility/packlink_load.js"}
// {$smarty.block.parent}
// {include file="backend/packlink_controllers/packlink_order_details_controller.js"}
// {include file="backend/packlink_controllers/packlink_order_list_controller.js"}
// {include file="backend/packlink_detail/packlink_order_detail_tab.js"}
//{/block}