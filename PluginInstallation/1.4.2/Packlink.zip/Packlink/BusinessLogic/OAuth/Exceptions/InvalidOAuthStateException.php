<?php

namespace Packlink\BusinessLogic\OAuth\Exceptions;

use Packlink\Infrastructure\Exceptions\BaseException;

class InvalidOAuthStateException extends BaseException
{

}